# Welcome to mi-ide

If you are new to mi-ide, We will take a very quick review to ease your start

* __ɱ __
         On the top left is a menu to access the editor configurations, you may access the menu by:
         - typing Ctrl-k + p (Control K the letter p)and then use the mouse.
         - or Ctrl-e then type : menu > settings (type "menu" <space> or <tab>, "settings" <enter>)

* __Basic Keys__

| Keys:      | Action              |
|------------|---------------------|
| F1         | Open file           |
| F2         | Save                |
| F3         | Save as             |
| F4         | Exit                |
| Ctrl-S     | Save                |
| Ctrl-Q     | Quit All            |
| Ctrl-W     | Close windor or tab |
| Ctrl-X     | Cut                 |
| Ctrl-C     | Copy                |
| Ctrl-V     | Paste               |
| Ctrl-F     | Search / Find       |
| Ctrl-R     | Search / Replace    |
| Ctrl-G     | Goto Line           |
| Ctrl-L     | Center on screen    |
| Ctrl-k + p | Activate mouse      |

* __Help__

|----------------------------------------------------|
| `Alt-?` Then type the section, available sections: |
| `Ctrl-e` Then type "help" then section name        |
| * defaultkeys : Full list of all keybindings       |
| * options     : Full list of options               |
| * help        : How to use help                    |

                   Enjoy coding !!
