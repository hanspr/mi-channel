# Welcome to mi-ide

If you are new to mi-ide, We will take a very quick review to easy your start

* _ɱ _ on the top left is a menu to access the editor configurations
* _Icons_ from left to right
	- File Cabinet (opens a file viewer), Save
	- Split Window Vertical, Split window Horizontal
	- Search, Replace, Upload File `(*)`, Download File `(*)`,
	- Close current window (if is the last window, close editor)

* _Basic Keys_

----------------------------------------
| Keys          :| Action              |                      -------------------------------------------------------
|----------------|---------------------|                      | `Help`                                              |
| F1             | Open file           |                      |                                                     |
| F2             | Save                |                      | `Alt-?` Then type the section, avaliable sections:  |
| F3             | Save as             |                      | * defaultkeys : Full list of all keybindings        |
| F4             | Exit                |                      | * options     : Full list of options                |
| Shift F1       | Open file viewwer   |                      | * help        : How to use help                     |
| Shift F2       | Save all            |                      -------------------------------------------------------
| F5 , F6        | Previous , Next     |
|                | Window or Search    |                      `(*)` Require a Cloud Key, for more information go to:
| F7 , F8        | Previous Next Tab   |                            github.com/hasnpr/mi-ide
| Ctrl-X         | Cut                 |                            Support & Services
| Ctrl-C         | Copy                |
| Ctrl-V         | Paste               |
| Ctrl-Q         | Quit All            |
| Ctrl-S         | Save                |
| Ctrl-F         | Ssearch / Find      |
| Ctrl-R         | Search / Replace    |
| Ctrl-G         | Goto Line           |
| Ctrl-L         | Center on screen    |
|                |                     |
| Alt-x  `(*)`   | Cut to Cloud        |
| Alt-c  `(*)`   | Copy to Cloud       |
| Alt-v  `(*)`   | Paste from Cloud    |
----------------------------------------

                                              Enjoy your coding !!
