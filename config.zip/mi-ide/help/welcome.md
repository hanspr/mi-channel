# Welcome to mi-ide

If you are new to mi-ide, We will take a very quick review to ease your start

* __ɱ __ on the top left is a menu to access the editor configurations, you may access the menu by typing Ctrl-P and then use the mouse.

* __Basic Keys__

----------------------------------------
| Keys          :| Action              |                      -------------------------------------------------------
|----------------|---------------------|                      | `Help`                                              |
| F1             | Open file           |                      |                                                     |
| F2             | Save                |                      | `Alt-?` Then type the section, available sections:  |
| F3             | Save as             |                      | * defaultkeys : Full list of all keybindings        |
| F4             | Exit                |                      | * options     : Full list of options                |
| Shift F1       | Open file viewer    |                      | * help        : How to use help                     |
| Shift F2       | Save all            |                      -------------------------------------------------------
| Ctrl-X         | Cut                 |                            Support & Services
| Ctrl-C         | Copy                |
| Ctrl-V         | Paste               |
| Ctrl-Q         | Quit All            |
| Ctrl-W         | Close windor or tab |
| Ctrl-S         | Save                |
| Ctrl-F         | Search / Find       |
| Ctrl-R         | Search / Replace    |
| Ctrl-G         | Goto Line           |
| Ctrl-L         | Center on screen    |
----------------------------------------

                                              Enjoy your coding !!
