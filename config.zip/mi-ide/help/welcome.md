# Welcome to mi-ide

If you are new to mi-ide, We will take a very quick review to ease your start

* __ɱ __ on the top left is a menu to access the editor configurations, you may access the menu by typing Ctrl-P and then use the mouse.

* __Basic Keys__

----------------------------------------                      -------------------------------------------------------
| Keys          :| Action              |                      | `Help`                                              |
|----------------|---------------------|                      |                                                     |
| F1             | Open file           |                      | `Alt-?` Then type the section, available sections:  |
| F2             | Save                |                      | * defaultkeys : Full list of all keybindings        |
| F3             | Save as             |                      | * options     : Full list of options                |
| F4             | Exit                |                      | * help        : How to use help                     |
| Ctrl-X         | Cut                 |                      -------------------------------------------------------
| Ctrl-C         | Copy                |
| Ctrl-V         | Paste               |
| Ctrl-Q         | Quit All            |
| Ctrl-W         | Close windor or tab |
| Ctrl-S         | Save                |
| Ctrl-F         | Search / Find       |
| Ctrl-R         | Search / Replace    |
| Ctrl-G         | Goto Line           |
| Ctrl-L         | Center on screen    |
| Ctrl-P         | Activate mouse      |
----------------------------------------

                                              Enjoy coding !!
