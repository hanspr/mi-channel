# Welcome to mi-ide

If you are new to mi-ide, We will take a very quick review to ease your start

__☰ __
     On the top left is a menu to access the editor configurations with your mouse.
     - If mouse is not active typing Ctrl-k + p (Control K the letter p) and then use the mouse.
     - If your terminal does not have mouse support or Ctrl-e then type :
       config > settings (type `config` <space> or <tab>, `settings` <enter>)

__Basic Keys__

| Keys:      | Action                             |
|------------|------------------------------------|
| F1         | Open file                          |
| F2         | Save                               |
| F3         | Save as                            |
| F4         | Exit                               |
| Ctrl-S     | Save                               |
| Ctrl-Q     | Quit All                           |
| Ctrl-W     | Close windor / tab / helper window |
| Ctrl-X     | Cut                                |
| Ctrl-C     | Copy                               |
| Ctrl-V     | Paste                              |
| Ctrl-F     | Search / Find                      |
| Ctrl-R     | Search / Replace                   |
| Ctrl-G     | Goto Line                          |
| Ctrl-L     | Center on screen                   |
| Ctrl-k + p | Activate mouse                     |

* __Help__

|----------------------------------------------------|
| `Alt-?` Then type the section, available sections: |
| `Ctrl-e` Then type `help` then section name        |
| * defaultkeys : Full list of all keybindings       |
| * commands : Full list of available commands       |
| * help        : How to use help                    |

     Enjoy coding !!
